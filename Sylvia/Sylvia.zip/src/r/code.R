rm(list = ls())
library(foreign)
setwd('F:/extra/Sylvia MSc')
data = read.spss('spss 1.sav')